The following files are required to run FindBugs.  These files can be downloaded from
http://findbugs.sourceforge.net/

AppleJavaExtensions.jar
annotations.jar
ant-junit.jar
asm-3.1.jar
asm-analysis-3.1.jar
asm-commons-3.1.jar
asm-tree-3.1.jar
asm-util-3.1.jar
asm-xml-3.1.jar
bcel.jar
commons-lang-2.4.jar
dom4j-1.6.1.jar
findbugs-ant.jar
findbugs.jar
jFormatString.jar
jaxen-1.1.1.jar
jsr305.jar
junit.jar

The following files are required to run PMD.  These files can be downloaded from
http://pmd.sourceforge.net/

asm-3.1.jar
jaxen-1.1.1.jar
junit-4.4.jar
pmd-4.2.5.jar

The following files are required to run Emma.  These files can be downloaded from
http://emma.sourceforge.net/

emma.jar
emma_ant.jar
metadata.emma

The following files are required to run Testng version 1.4.  These files can be downloaded from
http://testng.org/doc/download.html (However you can use other jars from previous versions
of testng that are compatible with version 1.4)

testng-5.8-jdk14.jar
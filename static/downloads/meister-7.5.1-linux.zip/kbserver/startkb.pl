# $Header: /CVS/openmake7/src/java/com.openmake.kbs.core.framework/startkb.pl,v 1.27 2012/01/28 00:50:26 quinn Exp $
#
#-- script to find and start the KB Server. Needs to put the script into the background
#   so that the Server persists after the Client is closed
#
use warnings;
use strict;
use File::Spec;
use File::Copy;
use IO::Uncompress::Unzip qw(unzip $UnzipError) ;

#-- everything is hardwired
$| = 1;

#-- find the install directory
my $full_path = File::Spec->rel2abs($0);
$full_path =~ s{\\}{/}g;
my @p = split /\//, $full_path;
pop @p;
my $install_dir    = join '/', @p;
my $jettycmdString = "";
my $stdout         = $install_dir . '/startkb_stdout.log';
my $stderr         = $install_dir . '/startkb_stderr.log';
my $jettystdout    = $install_dir . '/webclient_stdout.log';
my $jettystderr    = $install_dir . '/webclient_stderr.log';


if (-e $install_dir . "/instom.zip")
{
 my $str = strftime( "%Y%m%d.lic", localtime( $mtime ) );	
 unzip $install_dir . "/instom.zip" => $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/license/license.kb", Name => $str;
 unlink($install_dir . "/instom.zip");	
}


open( FP, "<$install_dir/kbs.ini" );
my @lines = <FP>;
close(FP);

my $line = shift @lines;
$line =~ s/JRE_DIR=//g;
$line =~ s/\n//g;
my $jredir = $line;

my $java_cmd;

if ( $^O !~ m{mswin|dos}i )
{
 $java_cmd = 'java';
}
else
{
 $java_cmd = 'java.exe';
}

my @args = ();

#-- configure the classpath
#-- JAG - 03.11.08 - case IUD-108. Add bfj220.jar
my $classpath       = "";
my $jetty_classpath = "";

if (-e $install_dir . "/tomcat/lib/quartz-1.5.0.jar")
{
 copy($install_dir . "/tomcat/lib/quartz-1.5.0.jar",   $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib/quartz-1.5.0.jar" );
}


if ( -e $jredir . "/lib/tools.jar" )
{
 copy( $jredir . "/lib/tools.jar", $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib/tools.jar" );
 copy( $jredir . "/lib/tools.jar", $install_dir . "/tomcat/lib/tools.jar" );
}
elsif ( -e $jredir . "/../lib/tools.jar" )
{
 copy( $jredir . "/../lib/tools.jar", $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib/tools.jar" );
 copy( $jredir . "/../lib/tools.jar", $install_dir . "/tomcat/lib/tools.jar" );
}
else
{
 my $jrever = "\"" . $jredir . "/bin/java\" -version 2>&1";
 @lines = `$jrever`;
 $line  = shift @lines;
 copy( $install_dir . "/tomcat/lib/tools_1.5.jar", $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib/tools.jar" ) if ( $line =~ /1\.5\./ );
 copy( $install_dir . "/tomcat/lib/tools_1.5.jar", $install_dir . "/tomcat/lib/tools.jar" ) if ( $line =~ /1\.5\./ );
 copy( $install_dir . "/tomcat/lib/tools_1.6.jar", $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib/tools.jar" ) if ( $line =~ /1\.6\./ );
 copy( $install_dir . "/tomcat/lib/tools_1.6.jar", $install_dir . "/tomcat/lib/tools.jar" ) if ( $line =~ /1\.6\./ );
}

#unlink ($install_dir . "/tomcat/lib/tools.jar");

sub createServerStartCmd()
{
 my $classpath = "";

 opendir DIR, $install_dir . "/tomcat/lib";

 while ( my $file = readdir DIR )
 {
  $classpath .= $install_dir . "/tomcat/lib/" . $file . ";" if ( $file =~ /\.jar/ && $file !~ /tools14\.jar/ && $file !~ /tools_1\.5\.jar/ );
 }
 closedir DIR;
 opendir DIR, $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib";

 while ( my $file = readdir DIR )
 {
  $classpath .= $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib/" . $file . ";" if ( $file =~ /\.jar/ );
 }

 my $jetty_classpath = "";

 if (-e $install_dir . "/jetty/lib")
 {
  opendir DIR, $install_dir . "/jetty/lib";

  while ( my $file = readdir DIR )
  {
   $jetty_classpath .= $install_dir . "/jetty/lib/" . $file . ";" if ( $file =~ /\.jar/ && $file !~ /tools14\.jar/ && $file !~ /tools_1\.5\.jar/ );
  }
  closedir DIR;
 }
 opendir DIR, $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib";

 while ( my $file = readdir DIR )
 {
  $jetty_classpath .= $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib/" . $file . ";" if ( $file =~ /\.jar/ );
 }
 
 my $jettyclasspath = "";

 closedir DIR;
 opendir DIR, $install_dir . "/tomcat/webapps/openmake.ear/webclient/WEB-INF/lib";

 while ( my $file = readdir DIR )
 {
  $jettyclasspath .= $install_dir . "/tomcat/webapps/openmake.ear/webclient/WEB-INF/lib/" . $file . ";" if ( $file =~ /\.jar/ );
 }

 if ( $^O =~ m{mswin|dos}i )
 {
  $classpath =~ s/\//\\/g;
  $jettyclasspath =~ s/\//\\/g;
  $jetty_classpath =~ s/\//\\/g;
 }
 else
 {
  $classpath =~ s/\\/\//g;
  $jettyclasspath =~ s/\\/\//g;
  $jetty_classpath =~ s/\\/\//g;
  
  $classpath =~ s/;/:/g;
  $jettyclasspath =~ s/;/:/g;
  $jetty_classpath =~ s/;/:/g;  
 }
 
 closedir DIR;
 my $webxml = $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/web.xml";

 open( FP, "<$webxml" );
 my @lines = <FP>;
 close(FP);

 my $str           = join( " ", @lines );
 my $webclientport = 58081;
 my $kbport = 58080;
 
 @lines = split( "\\<param-name\\>", $str );

 foreach my $line (@lines)
 {
  if ( $line =~ /-kbport/i )
  {
   if ($line =~ m/<param-value>(\d+)<\/param-value>/)
   {
    $kbport = $1;
    $webclientport = $kbport + 1;
    last;
   }	
  }
 }
 $jettycmdString = $java_cmd . " -Xms128m -Xmx512m -cp " . $jettyclasspath . " com.openmake.mgmtconsole.server.Jetty " . $webclientport . " " . $install_dir . "/tomcat/webapps/openmake.ear/webclient";
 my $cmd_string = "";

 #-- format the arguments
 my $arg = "";
 
 $arg = $ARGV[0] if (defined $ARGV[0]);
 
 if ( $arg =~ /jetty/i )
 {
  my $openmakewar = "\"" . $install_dir . "/tomcat/webapps/openmake.ear/openmake.war\"";
  my $soapwar     = "\"" . $install_dir . "/tomcat/webapps/openmake.ear/soap.war\"";

  push @args, $java_cmd;
  push @args, '-Xms128m';
  push @args, '-Xmx512m';
 # push @args, '-DNoWebClient=1';
  push @args, '-Dtomcat.home="' . $install_dir . '\tomcat"';

  # push @args, '-Djava.class.path="' . $jetty_classpath . '"';  # SBT - remove to shorten cmd line
  push @args, '-cp ';
  
  push @args, '"' . $jetty_classpath . '"';
  push @args, 'com.openmake.server.Jetty';
  push @args, $kbport;
  push @args, $openmakewar;
  push @args, $soapwar;

  $cmd_string = join( " ", @args );
print $cmd_string;
 }
 else
 {
  push @args, $java_cmd;
  push @args, '-Xms128m';
  push @args, '-Xmx512m';
#  push @args, '-DNoWebClient=1';
  push @args, '-Dtomcat.home="' . $install_dir . '\tomcat"';

  # push @args, ' -Djava.class.path="' . $classpath . '"';  # SBT - remove to shorten cmd line
  push @args, '-cp ';
  push @args, '"' . $classpath . '"';
  push @args, 'org.apache.tomcat.startup.Tomcat';
  push @args, '-home';
  push @args, '"' . $install_dir . '/tomcat"';

  $cmd_string = join( " ", @args );
 }

 return $cmd_string;
}

my $cmdString;
$cmdString = createServerStartCmd();

if ( $^O !~ m{mswin|dos}i )
{
 require POSIX;
 import POSIX;

 print "nohup $jettycmdString 1>$jettystdout 2>$jettystderr &\n";
 system("nohup $jettycmdString 1>$jettystdout 2>$jettystderr  &");

 #-- find and call the Start_KB scripts
 #-- fork before calling exec
 my $pid = fork;
 if ($pid)
 {

  #-- exit based as we are the parent shell;
  exit;
 }

 die "Could Not Fork: $!" unless defined($pid);
 close STDIN;
 close STDOUT;
 close STDERR;

 open STDOUT, '>', $stdout;
 open STDERR, '>', $stderr;

 POSIX::setsid() or die "Could Not Start New Session: $!";
 exec("$cmdString");

}    #-- End: if ( $^O !~ m{mswin|dos}i...

#-- do the windows.
#-- find a java command
close STDOUT;
close STDERR;

open STDOUT, '>', $stdout;
open STDERR, '>', $stderr;

#-- run the command. Use create process if it's available so that we can put it in the background

eval " use Win32; use Win32::Process; ";
if ($@)
{

 #-- can't use create process, use next best thing;
 system( 1, @args );
}
else
{
 no strict qw{ subs };    #-- prevents bareword subs error on NORMAL_PRIORITY_CLASS b/c it's loaded at run time

 sub ErrorReport
 {
  print Win32::FormatMessage( Win32::GetLastError() );
 }
 my $cmd;
 if ( -e $install_dir . "/kbs.ini" )
 {
  open my $fh, '<', $install_dir . "/kbs.ini";
  while (<$fh>)
  {
   chomp;
   if (s{^\s*JRE_DIR=}{})
   {
	$cmd = $_ . '\bin\javaw.exe';
	last;
   }
  }
  close $fh;
 }
 unless ( -e $cmd )
 {
  $cmd = FirstFoundInPath($java_cmd);
 }
 my $cmd_line = join ' ', @args;
 my $process;
 print "Install Dir: $install_dir\n";
 print "Using: $cmd\n";
 print "CmdLine: $cmd_line\n";

 Win32::Process::Create( $process, $cmd, $cmd_line, 0, NORMAL_PRIORITY_CLASS | DETACHED_PROCESS, $install_dir )
   || die ErrorReport();

 #if ( $ARGV[0] =~ /jetty/i )
 #{  
 # $cmd_line = $jettycmdString;
 
 # print "Install Dir: $install_dir\n";
 # print "Using: $cmd\n";
 # print "CmdLine: $cmd_line\n";

 # Win32::Process::Create( $process, $cmd, $cmd_line, 0, NORMAL_PRIORITY_CLASS | DETACHED_PROCESS, $install_dir )
 #  || die ErrorReport(); 
 # }
}

#------------------------------------------------------------------
sub FirstFoundInPath
{
 my $cmd = shift;
 my @ele = split /;/, $ENV{'PATH'};
 foreach my $d (@ele)
 {
  if ( -e $d . '/' . $cmd )
  {
   $cmd = $d . '/' . $cmd;
   last;
  }
 }

 $cmd =~ s{/}{\\}g;
 return $cmd;
}


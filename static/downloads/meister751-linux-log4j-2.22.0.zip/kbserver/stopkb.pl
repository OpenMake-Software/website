# $Header: /CVS/openmake7/src/java/com.openmake.kbs.core.framework/stopkb.pl,v 1.9 2011/06/29 20:05:23 steve Exp $
#
#-- script to find and stop the KB Server process. 
#
use warnings;
use strict;
use File::Spec;

#-- everything is hardwired
$| = 1; 

#-- find the install directory
my $full_path = File::Spec->rel2abs($0);
$full_path =~ s{\\}{/}g;
my @p = split /\//, $full_path;
pop @p;
my $install_dir = join '/', @p;
my $stdout      = $install_dir . '/stopkb_stdout.log';
my $stderr      = $install_dir . '/stopkb_stderr.log';

if ( $^O !~ m{mswin|dos}i )
{

my $cmd = "fuser " . $install_dir . "/tomcat/webapps/openmake.ear/openmake.war/WEB-INF/lib/omserver.jar";

my @lines = `$cmd`;
if ($?)
{
 $cmd = '/sbin/' . $cmd;
 @lines = `$cmd`;
}
my $line = shift @lines;

my @parts = split(/:/,$line);
my $pid = $parts[0];

print "Stop KBS...kill $pid\n";
print `kill $pid`;

$cmd = "fuser " . $install_dir . "/tomcat/webapps/openmake.ear/webclient/WEB-INF/lib/webclient.jar";

@lines = `$cmd`;
if ($?)
{
 $cmd = '/sbin/' . $cmd;
 @lines = `$cmd`;
}
$line = shift @lines;

@parts = split(/:/,$line);
$pid = $parts[0];

print "Stop WMC...kill $pid\n";
print `kill $pid`;

 exit 0;
} #-- End: if ( $^O !~ m{mswin|dos}i...

#-- do the windows.
#-- find a java command
close STDOUT;
close STDERR;

open STDOUT, '>', $stdout;
open STDERR, '>', $stderr;

my $java_cmd = 'java.exe';

#-- configure the classpath
my $classpath = 'XX_TOMCAT_XX\lib\jasper.jar;XX_TOMCAT_XX\lib\quartz-1.5.0.jar;XX_TOMCAT_XX\webapps\openmake.ear\openmake.war\WEB-INF\lib\omserver.jar;XX_TOMCAT_XX\webapps\openmake.ear\openmake.war\WEB-INF\lib\omint.jar;XX_TOMCAT_XX\webapps\openmake.ear\openmake.war\WEB-INF\lib\castor.jar;XX_TOMCAT_XX\webapps\openmake.ear\openmake.war\WEB-INF\lib\idooxoap.jar;XX_TOMCAT_XX\webapps\openmake.ear\openmake.war\WEB-INF\lib\commons-logging.jar;XX_TOMCAT_XX\webapps\openmake.ear\openmake.war\lib\log4j.jar;XX_TOMCAT_XX\lib\servlet.jar;XX_TOMCAT_XX\lib\webserver.jar;XX_TOMCAT_XX\webapps\openmake.ear\openmake.war\WEB-INF\lib\xerces.jar;XX_TOMCAT_XX\lib\xml-apis.jar;XX_TOMCAT_XX\lib\tools.jar;';
$classpath =~ s{XX_TOMCAT_XX}{$install_dir/tomcat}g;
$classpath =~ s{\\}{/}g;

#-- format the arguments
my @args = ();
push @args, $java_cmd;
push @args, '-Xms128m';
push @args, '-Xmx512m';
push @args, '-Dtomcat.home="' . $install_dir . '\tomcat"';
# push @args, '-Djava.class.path="' . $classpath . '"';  # SBT - remove to shorten cmd line
push @args, '-cp';
push @args, '"' . $classpath . '"';
push @args, 'org.apache.tomcat.startup.Tomcat';
push @args, '-stop';
push @args, '-home';
push @args, '"' . $install_dir . '/tomcat"';

#"Stop Param Number 0"="-stop"
#"Stop Param Number 1"="-home"
#"Stop Param Number 2"="C:\\Work\\Catalyst\\SourceCode\\Openmake700_Dev_Trunk\\DEV\\deploy\\meister-7.0-build163\\kbserver\\tomcat"
#"System.out File"="C:\\Work\\Catalyst\\SourceCode\\Openmake700_Dev_Trunk\\DEV\\deploy\\meister-7.0-build163\\kbserver\\tomcat\\logs\\stdout.log"
#"System.err File"="C:\\Work\\Catalyst\\SourceCode\\Openmake700_Dev_Trunk\\DEV\\deploy\\meister-7.0-build163\\kbserver\\tomcat\\logs\\stderr.log"

#-- we want to run the command and wait for it to finish
exec( @args );

#-- run the command. Use create process if it's available so that we can put it in the background
#eval " use Win32; use Win32::Process; ";
#if ( $@ )  
#{
# #-- can't use create process, use next best thing;
# system( 1, @args);
#}
#else
#{
# no strict qw{ subs }; #-- prevents bareword subs error on NORMAL_PRIORITY_CLASS b/c it's loaded at run time
# 
# sub ErrorReport
# {
#  print Win32::FormatMessage( Win32::GetLastError() );
# }
# my $cmd;
# if ( -e $install_dir . "/kbs.ini" )
# {
#  open my $fh , '<', $install_dir . "/kbs.ini";
#  while ( <$fh> )
#  {
#   chomp;
#   if ( s{^\s*JRE_DIR=}{} )
#   {
#    $cmd = $_ . '\bin\java.exe';
#    last;
#   }
#  }
#  close $fh;
# }
# unless ( -e $cmd )
# {
#  $cmd = FirstFoundInPath( $java_cmd );
# }
# my $cmd_line = join ' ', @args;
# my $process; 
# print "Install Dir: $install_dir\n";
# print "Using: $cmd\n"; 
# print "CmdLine: $cmd_line\n";
# 
# Win32::Process::Create( $process,
#                         $cmd,
#                         $cmd_line,
#                         0,
#                         NORMAL_PRIORITY_CLASS | DETACHED_PROCESS, $install_dir )
#                         || die ErrorReport();
#                         ;
#
#}

#------------------------------------------------------------------
sub FirstFoundInPath
{
 my $cmd = shift;
 my @ele = split /;/, $ENV{'PATH'};
 foreach my $d ( @ele )
 {
  if ( -e $d . '/' . $cmd )
  {
   $cmd = $d . '/' . $cmd;
   last;
  }
 }

 $cmd =~ s{/}{\\}g;
 return $cmd ;
}





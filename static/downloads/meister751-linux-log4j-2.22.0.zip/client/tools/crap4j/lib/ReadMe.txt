The following files are required to run Crap4J.  These files can be downloaded from
http://www.crap4j.org/

args4j-2.0.1.jar
asmlib.jar
org.crap4j.jar
retroweaver-all-2.0.2.jar

and extracted Eclipse plugins:

com.agitar.eclipse.api_4.2.0.401405
com.agitar.eclipse.coverage_4.2.0.401405

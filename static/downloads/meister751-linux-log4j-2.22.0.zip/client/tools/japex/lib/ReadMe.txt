The following files are required to run Japex.  These files can be downloaded from
https://japex.dev.java.net/

activation.jar
ant.jar
japex.jar
jaxb-api.jar
jaxb-impl.jar
jaxb-xjc.jar
jcommon-1.0.0-rc1.jar
jfreechart-1.0.0-rc1.jar
jsr173_api.jar
mail.jar
sjsxp.jar

The following files are required to run CheckStyle.  These files can be downloaded from
http://checkstyle.sourceforge.net/


1. checkstyle-5.0.jar
2. ANTLR 2.7.2 classes. antlr.jar is included in the distribution.
3. Jakarta Commons Beanutils classes. commons-beanutils.jar is included in the distribution.
4. Jakarta Commons Collections classes. commons-collections.jar is included in the distribution.
5. Jakarta Commons Logging classes. commons-logging.jar is included in the distribution.
6. A JAXP compliant XML parser implementation. You already have it on your system if you run ANT or JDK 1.4.

For example:

antlr.jar
buildFinishListener.jar
checkstyle-5.0-beta01.jar
checkstyle-all-5.0-beta01.jar
commons-beanutils-core.jar
commons-cli-1.1.jar
commons-logging.jar
google-collect-snapshot-20080321.jar

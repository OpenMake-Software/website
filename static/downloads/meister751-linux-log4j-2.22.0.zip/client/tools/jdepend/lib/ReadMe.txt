The following files are required to run JDepend.  These files can be downloaded from
http://www.clarkware.com/software/JDepend.html

ant-jdepend.jar
jdepend-2.9.jar

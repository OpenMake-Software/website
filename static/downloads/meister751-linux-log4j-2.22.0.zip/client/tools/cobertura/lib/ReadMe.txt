The following files are required to run Cobertura.  These files can be downloaded from
http://cobertura.sourceforge.net/

asm-3.0.jar
asm-tree-3.0.jar
cobertura.jar
jakarta-oro-2.0.8.jar
log4j-1.2.9.jar

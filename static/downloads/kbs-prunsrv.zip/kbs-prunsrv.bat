setlocal

rem === Configuration ===
set SERVICE_NAME=MeisterKBS
set DISPLAY_NAME=MeisterKBS
set DESCRIPTION=Meister running with Java JDK 23
set PRUNSRV_PATH=C:\Program Files\Meister_751_Azul_jdk\kbserver\prunsrv.exe
set JAVA_EXEC=C:\Program Files\Java\Azul-jdk23\bin\server\jvm.dll
set TOMCAT_HOME=C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat
set LOG_PATH=C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\logs

rem === Complete classpath ===
set CLASSPATH="C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\lib\jasper.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\lib\quartz-1.5.0.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\lib\servlet.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\lib\tools.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\lib\tools_1.6.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\lib\webserver.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\lib\xalan.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\lib\xml-apis.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\ant-launcher.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\ant.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\bfj220.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\castor.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\commons-codec-1.3.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\commons-httpclient-3.1.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\commons-logging.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\IdooXoap.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\log4j.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\log4j-api-2.22.0.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\log4j-core-2.22.0.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\omcmdline.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\omint.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\omserver.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\postgresql.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\quartz-1.5.0.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\xerces.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\xercesImpl.jar;C:\Program Files\Meister_751_Azul_jdk\kbserver\tomcat\webapps\openmake.ear\openmake.war\WEB-INF\lib\xml-apis.jar"

rem === Install the service ===
"%PRUNSRV_PATH%" "//IS/%SERVICE_NAME%" --DisplayName="%DISPLAY_NAME%" --Description="%DESCRIPTION%" --Startup=auto --StartMode=jvm --StartClass=org.apache.tomcat.startup.Tomcat "--StartParams=-home;%TOMCAT_HOME%" --Jvm="%JAVA_EXEC%" "--JvmOptions=-Xms128m;-Xmx512m;-Dtomcat.home=%TOMCAT_HOME%" --Classpath="%CLASSPATH%" --StopMode=jvm --StopClass=org.apache.catalina.startup.Bootstrap --StopParams=stop --LogPath="%LOG_PATH%" --LogLevel=Debug --StdOutput=auto --StdError=auto

echo.
echo Service %SERVICE_NAME% installed successfully.
pause
endlocal

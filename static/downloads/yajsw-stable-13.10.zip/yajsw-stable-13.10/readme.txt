yajsw-stable-13.10

    * New: support jdk 19/20: update to groovy 4.0.12
    * Bug: Logging not substituting variables	
	
Note: support the project by donating:

dogecoin: D84dTitLwAjvoTvZBi97mYdTKvtyJrc3xR
bitcoin:  bc1q5yghsmwj3k2ak7hpvrzd3gmpev5p089msqe4nr
polygon:  0xC46ffecEb6403452443AcC27E45335a589ca7eea